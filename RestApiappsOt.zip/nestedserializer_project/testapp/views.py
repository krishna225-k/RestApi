from django.shortcuts import render
from testapp.models import Author,Book
from testapp.serializers import AuthorSerializer,BookSerializer
from rest_framework import generics


# Create your views here.
class AuthorListView(generics.ListCreateAPIView): # perform list,create  operations
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer


class AuthorView(generics.RetrieveUpdateDestroyAPIView): # perform update,retrieve, delete operations end point
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer


class BookListView(generics.ListCreateAPIView): # perform list,create  operations
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class BookView(generics.RetrieveUpdateDestroyAPIView): # perform update,retrieve, delete operations end point
    queryset = Book.objects.all()
    serializer_class = BookSerializer
