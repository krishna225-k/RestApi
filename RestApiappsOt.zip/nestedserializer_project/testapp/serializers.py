from rest_framework import serializers
from testapp.models import Author,Book


class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = '__all__'



class AuthorSerializer(serializers.ModelSerializer):
    books_by_author = BookSerializer(read_only=True,many=True) # allow to access the books information inside the Author serializers. know to be nested serializers
    class Meta:
        model = Author
        fields = '__all__'
