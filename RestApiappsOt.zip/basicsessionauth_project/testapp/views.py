from django.shortcuts import render
from testapp.models import Employee
from rest_framework.viewsets import ModelViewSet
from testapp.serializers import EmployeeModelSerializer
# Create your views here.
# from testapp.permissions import IsReadOnly,IsGETOrPatch,HariPermission # custom permissions
# implement the authenication and authorization functionality
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated
# class EmployeeCURDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeModelSerializer
    # ''' Below lines was used to implement allowing only Registered users'''
    # authentication_classes = [TokenAuthentication]
    # permission_classes = [IsAuthenticated]
    # ''' Below lines was allowing in admin user to access endpoings '''
    # authentication_classes = [TokenAuthentication,]
    # permission_classes = [IsAdminUser,]

    # '''
    # Below lines will allowing users which has authenicated(Registered users) then allowing to write(POST,PUT,PATCH,DELETE) operation. if not authenicated then allowing only ReadOnly (i.e able to perform only GET,OPTION,HEAD)
    # '''

    # authentication_classes = [TokenAuthentication,]
    # ''' Below lines was demonstating the how to user DjangoModelPermissions can implemented and consumed.
    # as per DjangoModelPermissions: permissions for GET operation need token authenication required.
    # for other operation like:(POST,PUT,PATCH,DELETE) required both authenication and DjangoModelPermissions
    #  '''
    # authentication_classes = [TokenAuthentication,]
    # permission_classes = [DjangoModelPermissions,]
    # ''' demonstating the the DjangoModelPermissionsOrAnonReadOnly:--- for touching end point no need to any TokenAuthentication. for write permissions only model permissions required'''
    # authentication_classes = [TokenAuthentication,]
    # permission_classes = [DjangoModelPermissionsOrAnonReadOnly,]

    # '''demonstating the custom permissions'''
    # authentication_classes = [TokenAuthentication,]
    # permission_classes = [IsReadOnly,]

    # '''demonstating the custom permissions'''
    # authentication_classes = [TokenAuthentication,]
    # permission_classes = [IsGETOrPatch,]

    # '''demonstating the custom permissions,complex cutomization'''
    # authentication_classes = [TokenAuthentication,]
    # permission_classes = [HariPermission,]


# from rest_framework_jwt.authentication import JSONWebTokenAuthentication
# ''' demonstating the enable the JWT authenication'''
# class EmployeeCURDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeModelSerializer
#     authentication_classes = [JSONWebTokenAuthentication,]
#     permission_classes = [IsAuthenticated,]
#
# ''' CustomAuthentication implementation'''
# from testapp.authentications import CustomAuthentication
# class EmployeeCURDCBV(ModelViewSet):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeModelSerializer
#     authentication_classes = [CustomAuthentication,]
#     permission_classes = [IsAuthenticated,]

# ''' CustomAuthentication2 implementation'''
# from testapp.authentications import CustomAuthentication2
from rest_framework.authentication import SessionAuthentication
class EmployeeCURDCBV(ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    # authentication_classes = [BasicAuthentication,]
    authentication_classes = [SessionAuthentication,]
    permission_classes = [IsAuthenticated,]
