from django.shortcuts import render
from rest_framework.views import APIView
# response class will convert to python dict into the json data
from rest_framework.response import Response
from testapp.serializers import NameSerializer

# Create your views here.
class TestAPIView(APIView):
    def get(self,request,*args,**kwargs):
        colors = ['RED','YELLOW','GREEN','BLUE']
        return Response({'msg':'Happy Pongal','colors':colors}) # it's json response. Response()--> class will convert the python dict to json response

    def post(self,request,*args,**kwargs):
        serializer = NameSerializer(data=request.data)
        if serializer.is_valid():
            name = serializer.data.get('name')
            msg = 'Hello {}, Happy Pongal..!!!'.format(name)
            return Response({'msg':msg})
        return Response(serializer.errors,status=400)

    def put(self,request,*args,**kwargs):
        return Response({'msg':'this response is from put method of APIView'})

    def delete(self,request,*args,**kwargs):
        return Response({'msg':'this response is from delete method of APIView'})

# demonstrate the ViewSet()
from rest_framework import viewsets
class TestViewSet(viewsets.ViewSet):
    def list(self,request):
        colors = ['RED','YELLOW','GREEN','BLUE']
        return Response({'msg':'Happy New Year...!','colors':colors}) # it's json response. Response()--> class will convert the python dict to json response

    def create(self,request):
        serializer = NameSerializer(data=request.data)
        if serializer.is_valid():
            name = serializer.data.get('name')
            msg = 'Hello {}, Happy Dhasura ..!!!'.format(name)
            return Response({'msg':msg})
        return Response(serializer.errors,status=400)

    def retrieve(self,request,pk=None):
        return Response({'msg':'this method is from retrieve method of ViewSet'})

    def update(self,request,pk=None):
        return Response({'msg':'this method is from update method of ViewSet'})

    def partial_update(self,request,pk=None):
        return Response({'msg':'this method is from partial_update method of ViewSet'})

    def destroy(self,request,pk=None):
        return Response({'msg':'this method is from destroy method of ViewSet'})
