# from django.shortcuts import render
from django.http.response import HttpResponse


# Create your views here.

def emp_data_view(request):
    emp_data = {
        'eno': 101,
        'ename': 'Hari',
        'esal': 1000,
        'eaddress': 'Mumbai'
    }
    resp = '</h1> Employee Number:{} <br>Employee Name:{} </br>Employee Salary:{} </br>Employee Address:{}</h1>'.format(
        emp_data["eno"], emp_data['ename'], emp_data['esal'], emp_data['eaddress'])

    return HttpResponse(resp)


import json


def emp_data_jsonview(request):
    emp_data = {
        'eno': 101,
        'ename': 'Hari',
        'esal': 1000,
        'eaddress': 'Mumbai'
    }
    json_data = json.dumps(emp_data)
    # resp = '</h1> Employee Number:{} <br>Employee Name:{} </br>Employee Salary:{} </br>Employee Address:{}</h1>'.format(emp_data["eno"],emp_data['ename'],emp_data['esal'],emp_data['eaddress'])

    return HttpResponse(json_data, content_type='application/json')


from django.http.response import JsonResponse


def emp_data_jsonview2(request):
    emp_data = {
        'eno': 101,
        'ename': 'Hari',
        'esal': 1000,
        'eaddress': 'Mumbai'
    }
    # json_data = json.dumps(emp_data)
    # resp = '</h1> Employee Number:{} <br>Employee Name:{} </br>Employee Salary:{} </br>Employee Address:{}</h1>'.format(emp_data["eno"],emp_data['ename'],emp_data['esal'],emp_data['eaddress'])

    # return HttpResponse(json_data, content_type='application/json')
    return JsonResponse(emp_data)

    # Creating json response with help of classBasedViews


from django.views.generic import View


class JsonCBV(View):
    def get(self, request, *args, **kwargs):
        emp_data = {
            'eno': 101,
            'ename': 'Hari',
            'esal': 1000,
            'eaddress': 'Mumbai'
        }
        return JsonResponse(emp_data)


from django.views.generic import View


class JsonCBV1(View):

    def get(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from get method'})
        return HttpResponse(json_data, content_type='application/json')

    def post(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from post method'})
        return HttpResponse(json_data, content_type='application/json')

    def put(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from get method'})
        return HttpResponse(json_data, content_type='application/json')

    def delete(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from get method'})
        return HttpResponse(json_data, content_type='application/json')


# class based views code reusablity with help of the 'MIxin' clss

from testapp.mixin import HttpResponseMixin
from django.views.generic import View
class JsonCBV_mixin(View):

    def get(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from get method'})
        # return HttpResponse(json_data, content_type='application/json')
        return self.render_to_http_response(json_data)

    def post(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from post method'})
        return self.render_to_http_response(json_data)

    def put(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from get method'})
        return self.render_to_http_response(json_data)

    def delete(self, request, *args, **kwargs):
        json_data = json.dumps({'msg': 'This is from get method'})
        # return HttpResponse(json_data, content_type='application/json')
        return self.render_to_http_response(json_data)
