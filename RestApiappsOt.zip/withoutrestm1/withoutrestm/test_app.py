import requests
ENDPOINT = 'modelapi/'
def get_resource():
    resp = requests.get(BASE_URL+ENDPOINT)
    BASE_URL = 'http://127.0.0.1:8000/'
    print(resp.status_code)
    print(resp.json())
get_resource()
