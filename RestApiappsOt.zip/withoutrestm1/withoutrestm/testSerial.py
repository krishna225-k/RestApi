
import requests
BASE_URL = 'http://127.0.0.1:8000/'
ENDPOINT = 'modelserial/'

def get_resource(id):
    resp = requests.get(BASE_URL+ENDPOINT+id)
    print(BASE_URL+ENDPOINT+id)
    print(resp.status_code)
    print(resp.json())
id = input('Enter ID here: ')
get_resource(id)
