
import requests
import json
BASE_URL = 'http://127.0.0.1:8000/'
ENDPOINT = 'itemdelete/'

def delete_resource(id):

    # resp = requests.post(BASE_URL+ENDPOINT,data=new_data)
    resp = requests.delete(BASE_URL+ENDPOINT+str(id)) # valid formate
    print(resp.status_code)
    print(resp.json())
delete_resource(4)
