
import requests
import json
BASE_URL = 'http://127.0.0.1:8000/'
# ENDPOINT = 'formvalidation/'
ENDPOINT = 'detailsput/'
def update_resource(id):
    new_data = {
    'esal':10000,
    'eaddr':'Bengulur'
    }
    # resp = requests.post(BASE_URL+ENDPOINT,data=new_data)
    resp = requests.put(BASE_URL+ENDPOINT+str(id),data=json.dumps(new_data)) # valid formate
    # print(resp.status_code)
    print(resp.json())
update_resource(1)
