
import requests
BASE_URL = 'http://127.0.0.1:8000/'
ENDPOINT = 'tryexceptclient/'

# def get_resource():
#     resp = requests.get(BASE_URL+ENDPOINT)
#     print(BASE_URL+ENDPOINT+id)
#     print(resp.status_code)
#     print(resp.json())
# id = input('Enter ID here: ')
# get_resource(id)
def get_resource(id):
    resp = requests.get(BASE_URL+ENDPOINT+id)
    # if resp.status_code in range(200,300):
    if resp.status_code == requests.codes.ok: # both of any line will work
        # print(resp.status_code)
        print(resp.json())
    else:
        print('something went wrong')
id = input('Enter id: ')
get_resource(id)
