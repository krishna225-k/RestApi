
import requests
import json
BASE_URL = 'http://127.0.0.1:8000/'
ENDPOINT = 'posttomodel/'

def get_resource(id):
    resp = requests.get(BASE_URL+ENDPOINT+id)
    print(resp.status_code)
    print(resp.json())

def get_all():
    resp = requests.get(BASE_URL+ENDPOINT)
    print(resp.status_code)
    print(resp.json())

# get_resource('3')
# get_resource('100')
def create_resource():
    new_data = {
    'eno':120,
    'ename':'sunder',
    'esal':2200,
    'eaddr':'chennai'
    }
    # resp = requests.post(BASE_URL+ENDPOINT,data=new_data)
    resp = requests.post(BASE_URL+ENDPOINT,data=json.dumps(new_data)) # valid formate 
    print(resp.status_code)
    print(resp.json())
create_resource()
