
import requests
import json

resp = requests.get('https://api.coindesk.com/v1/bpi/currentprice.json')
pdata = resp.json()
print(pdata.items())
for parm in pdata.items():
    print(parm)
    print('\n')
