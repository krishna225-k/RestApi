import json
def is_json(data):
    try:
        p_data = json.loads(data)
        value = True
    except ValueError:
        value = False
    return value
