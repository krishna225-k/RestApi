from django.shortcuts import render
from django.views.generic import View
from testapp.models import Employee
# import json
from django.http.response import HttpResponse
# converting python dict into jsob objects. instead of json.dumps with help of serializers
# from django.core.serializers import serialize
from testapp.mixin import SerializeMixin
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from testapp.mixin import HttpResponseMixin

from testapp.utils import is_json
# Create your views here.

# part of the code session-9
@method_decorator(csrf_exempt,name='dispatch')
class EmployeeCURD(HttpResponseMixin,SerializeMixin,View):
    def get_object_by_id(self,id):
        try:
            emp = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            return None # if object not available then return nothing
        else:
            return emp

    def get(self,request,*args,**kwargs):
        data = request.body
        print(data)
        valid_json = is_json(data)
        if not valid_json:
            json_data = json.dumps({'msg':'Please send valid json data1'})
            return self.render_to_httpresponse(json_data,status=400)
        pdata = json.loads(data)
        id = pdata.get('id',None)
        if id is not None: # when valid id is exist then only loop executs
            emp = self.get_object_by_id(id)
            print(emp)
            if emp is None: # if you not found the emp data, then only executes loop further
                json_data = json.dumps({'msg':'Requested Resource not available'})
                return self.render_to_httpresponse(json_data,status=404)
            # if emp found details about employee. then connvert json object and return
            json_data = self.serialize([emp,])
            return self.render_to_httpresponse(json_data,status=200)

        # if client not sending any data id . then all data need to display
        qs = Employee.objects.all()
        json_data = self.serialize(qs)
        return self.render_to_httpresponse(json_data,status=200)

    def post(self,request,*args,**kwargs):
        data = request.body
        valid_json = is_json(data)
        if not valid_json:
            json_data = json.dumps({'msg':'Please send valid json data1'})
            return self.render_to_httpresponse(json_data,status=400)
        empdata = json.loads(data)
        print(empdata)
        form = EmployeeForm(empdata)
        if form.is_valid():
            form.save(commit=True)
            json_data = json.dumps({'msg':'Resource created Successfully'})
            return self.render_to_httpresponse(json_data)

        if form.errors:
            json_data = json.dumps(form.errors)
            return self.render_to_httpresponse(json_data)


    def put(self,request,*args,**kwargs):
        data = request.body # Get the clinet data
        valid_json = is_json(data) # validate wether json are not
        if not valid_json: # if not json object just errors note to client
            json_data = json.dumps({'msg':'Please send valid json data1'})
            return self.render_to_httpresponse(json_data,status=400)
        pdata = json.loads(data) # if the client provided valid json data, then convert the client object into python dict,
        id = pdata.get('id',None) #  extract or get client id from client extracted 'client' id from dict from clinet
        if id is None: # if clinet dict not have the id
            json_data = json.dumps({'msg':'To perform update Id is mandotary'})
            return self.render_to_httpresponse(json_data,status=400) # return issue to clinet
        emp = self.get_object_by_id(id) # clinet data has the id, the retrive the crosponding id details from database
        if emp is None: # if the none of employee haveing with Id,
            json_data = json.dumps({'msg':'Requested id not found, update failed'}) # retrun same thing with clinet
            return self.render_to_httpresponse(json_data,status=400)
        provided_data = json.loads(data) # if resources have clinet details, convert data to py dict
        original_data = { # reassing the provided data with existing dat
        'eno':emp.eno,
        'ename':emp.ename,
        'esal':emp.esal,
        'eaddr':emp.eaddr,
        }
        original_data.update(provided_data) # perform the modification
        form = EmployeeForm(original_data,instance=emp) # update Form
        if form.is_valid(): # if form was matching all fields valid then
            form.save(commit=True) # retrun the database
            json_data = json.dumps({'msg':'Resources updated Successfully'}) # return same status to client
            return self.render_to_httpresponse(json_data)
        if form.errors: # if form contains any erros same return the clinet
            json_data = json.dumps(form.errors)
            return self.render_to_httpresponse(json_data)


    def delete(self,request,*args,**kwargs):
        data = request.body
        print(data)
        valid_json = is_json(data)
        if not valid_json:
            json_data = json.dumps({'msg':'Please send valid json data1'})
            return self.render_to_httpresponse(json_data,status=400)
        pdata = json.loads(data)
        id = pdata.get('id',None)
        if id is not None: # when valid id is exist then only loop executs
            emp = self.get_object_by_id(id)
            print(emp)
            if emp is None: # if you not found the emp data, then only executes loop further
                json_data = json.dumps({'msg':'Requested Resource not available'})
                return self.render_to_httpresponse(json_data,status=404)
            # if emp found details about employee. then connvert json object and return
            status,deleted_item = emp.delete()
            if status == 1:
                json_data = json.dumps({'msg':'Resource Deleted Successfully'})
                return self.render_to_httpresponse(json_data,status=200)

            json_data = json.dumps({'msg':'Unable to delete.. Please Try after sometime..'})
            return self.render_to_httpresponse(json_data,status=404)
        json_data = json.dumps({'msg':'To Peform delete.. Id is mandotary Plelase provide id.'})
        return self.render_to_httpresponse(json_data,status=404)











class EmployeeDetailCBV(View):
    def get(self,request,*agrs,**kwargs):
        emp = Employee.objects.get(id=2)
        emp_data = {
        'eno':emp.eno,
        'ename':emp.ename,
        'esal':emp.esal,
        'eaddr':emp.eaddr
        }
# after the  retrived dict from database table need to convert as json object with help of the json.dumps()
        json_data = json.dumps(emp_data)
        return HttpResponse(json_data,content_type='application/json')


# Getting the Employee id from client end

class EmployeeDetailCBVUser(View):
    def get(self,request,id,*agrs,**kwargs):
        emp = Employee.objects.get(id=id)
        emp_data = {
        'eno':emp.eno,
        'ename':emp.ename,
        'esal':emp.esal,
        'eaddr':emp.eaddr
        }
# after the  retrived dict from database table need to convert as json object with help of the json.dumps()
# converting python dict into json object is serialization
        json_data = json.dumps(emp_data)
        return HttpResponse(json_data,content_type='application/json')

class EmployeeDetailCBVserializer(SerializeMixin,View):
    def get(self,request,id,*args,**kwargs):
        emp = Employee.objects.get(id=id)
        # json_data = serialize('json',[emp,]) # complete data will send to data to client end
        json_data = self.serialize([emp,])
        # fields=('eno','ename','eaddr')
         # only specified fileds only we send to client end
        return HttpResponse(json_data,content_type='application/json')


class EmployeeDetailListCBV(View):
    def get(self,request,*args,**kwargs):
        qs = Employee.objects.all()
        json_data = serialize('json',qs)
        return HttpResponse(json_data,content_type='application/json')


'''
Avoiding the getting meta data from while retrive information with json objects
'''

class EmployeeDetailListCBVwithFields(View):
    def get(self,request,*args,**kwargs):
        qs = Employee.objects.all()
        # with the fields argument we can control the which fields need to display to client
        json_data = serialize('json',qs,fields=('eno','ename','eaddr'))
        # converting the json object into python dict with json.loads()
        p_dict = json.loads(json_data)
        final_list = []
        for obj in p_dict:
            emp_data = obj['fields']
            final_list.append(emp_data)
        # converting the python dict into json object with json.dumps()
        json_data = json.dumps(final_list)
        return HttpResponse(json_data,content_type='application/json')


'''
Write the additional functinality. which was converting from json object into python dict.
overtcoming by writing the Mixin functonality
'''

class EmployeeDetailCBVserializerMixin(SerializeMixin,View):
    def get(self,request,*args,**kwargs):
        emp_data = Employee.objects.all()
        json_data = self.serialize(emp_data)
        return HttpResponse(json_data,content_type='application/json')




'''
writing View function with try: expecpt: else:
To handling the try: and expecpt:
'''
import json
class EmployeeTryExcept(SerializeMixin,View):
    def get(self,request,id,*args,**kwargs):
        try:
            emp = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            json_data = json.dumps({'msg':'The requsets resources not available'})
            return HttpResponse(json_data,content_type='application/json',status=404)
        else:
            json_data = self.serialize([emp,])
        # return HttpResponse(json_data,content_type='application/json')
            return HttpResponse(json_data,content_type='application/json',status=200) # HttpResponse with status code


class EmployeeTryExceptOverClient(SerializeMixin,View):
    def get(self,request,id,*args,**kwargs):

        emp = Employee.objects.get(id=id)
        # except Employee.DoesNotExist:
        json_data = json.dumps({'msg':'The requsets resources not available'})
        # else:
        json_data = self.serialize([emp,])
        return HttpResponse(json_data,content_type='application/json')


'''
Demonstrating the Mixin with HttpResponse:
'''

from testapp.mixin import HttpResponseMixin
class EmployeeDetailCBVMixinHttp(HttpResponseMixin,SerializeMixin,View):
    def get(self,request,id,*args,**kwargs):
        try:
            emp_data = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            json_data = json.dumps({'msg':'Requested resources not available'})
            return self.render_to_httpresponse(json_data)
        else:
            json_data = self.serialize([emp_data,])
        # return HttpResponse(json_data,content_type='application/json')
            return self.render_to_httpresponse(json_data)

# Implement post method along with classbased Views

@method_decorator(csrf_exempt,name='dispatch')
class EmployeeDetailCBVPost(HttpResponseMixin,SerializeMixin,View):
    def get(self,request,id,*args,**kwargs):
        try:
            emp_data = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            json_data = json.dumps({'msg':'Requested resources not available'})
            return self.render_to_httpresponse(json_data)
        else:
            json_data = self.serialize([emp_data,])
        # return HttpResponse(json_data,content_type='application/json')
            return self.render_to_httpresponse(json_data)

    # def post(self,request,*args,**kwargs):
    #     json_data = json.dumps({'msg':'This post method'})
    #     return self.render_to_httpresponse(json_data)

    # validation function for the json data
    def post(self,request,*args,**kwargs):
        data = request.body
        valid_json = is_json(data)
        if not valid_json:
            json_data = json.dumps({'msg':'Please send valid json data only'})
            return self.render_to_httpresponse(json_data,status=400)
        json_data = json.dumps({'msg':'Valid Json data'})
        return self.render_to_httpresponse(json_data,status=200)




# As part of peforming the PUT method
# from testapp.models import Employee
from testapp.forms import EmployeeForm
from django import  forms

@method_decorator(csrf_exempt,name='dispatch')
class EmployeeDetailCBVPostFormValidation(HttpResponseMixin,SerializeMixin,View):

    def get_object_by_id(self,id):
        try:
            emp = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            return None
        return emp

    def get(self,request,id,*args,**kwargs):
        try:
            emp_data = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            json_data = json.dumps({'msg':'Requested resources not available'})
            return self.render_to_httpresponse(json_data)
        else:
            json_data = self.serialize([emp_data,])
        # return HttpResponse(json_data,content_type='application/json')
            return self.render_to_httpresponse(json_data)

    # def post(self,request,*args,**kwargs):
    #     json_data = json.dumps({'msg':'This post method'})
    #     return self.render_to_httpresponse(json_data)

    # validation function for the json data
    def post(self,request,*args,**kwargs):
        data = request.body
        valid_json = is_json(data)
        if not valid_json:
            json_data = json.dumps({'msg':'Please send valid json data only'})
            return self.render_to_httpresponse(json_data,status=400)
        empdata = json.loads(data)
        form = EmployeeForm(empdata)
        if form.is_valid():
            form.save()
            json_data = json.dumps({'msg':'Resource is created'})
            return self.render_to_httpresponse(json_data)
        # after forms.py file fail the below lines will executes
        if form.errors:
            json_data = json.dumps(form.errors)
            return self.render_to_httpresponse(json_data,status=400)

    def put(self,request,id,*args,**kwargs):
        print('hari')
        emp = self.get_object_by_id(id)
        if emp is None:
            json_data = json.dumps({'msg':'No Matched Resources found, Not Possible to perform Updation'})
            return self.render_to_httpresponse(json_data,status=4040)
        data = request.body
        valid_json = is_json(data)
        if not valid_json:
            json_data = json.dumps({'msg':'Please send valid json data only'})
            return self.render_to_httpresponse(json_data,status=400)
        provided_data = json.loads(data)
        original_data = {
        'eno':emp.eno,
        'ename':emp.ename,
        'esal':emp.esal,
        'eaddr':emp.eaddr
        }
        original_data.update(provided_data)
        form = EmployeeForm(original_data,instance=emp)
        if form.is_valid():
            form.save(commit=True)
            json_data = json.dumps({'msg':'Resource is created'})
            return self.render_to_httpresponse(json_data)
        # after forms.py file fail the below lines will executes
        if form.errors:
            json_data = json.dumps(form.errors)
            return self.render_to_httpresponse(json_data,status=400)


# for varification of put method
@method_decorator(csrf_exempt,name='dispatch')
class EmployeeDetailPut(HttpResponseMixin,SerializeMixin,View):

    def get_object_by_id(self,id):
        try:
            emp = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            return None
        return emp


    def put(self,request,id,*args,**kwargs):
        print('hari')
        emp = self.get_object_by_id(id)
        if emp is None:
            json_data = json.dumps({'msg':'No Matched Resources found, Not Possible to perform Updation'})
            return self.render_to_httpresponse(json_data,status=4040)
        data = request.body
        valid_json = is_json(data)
        if not valid_json:
            json_data = json.dumps({'msg':'Please send valid json data only'})
            return self.render_to_httpresponse(json_data,status=400)
        provided_data = json.loads(data)
        original_data = {
        'eno':emp.eno,
        'ename':emp.ename,
        'esal':emp.esal,
        'eaddr':emp.eaddr
        }
        original_data.update(provided_data)
        form = EmployeeForm(original_data,instance=emp)
        if form.is_valid():
            form.save(commit=True)
            json_data = json.dumps({'msg':'Resource is created'})
            return self.render_to_httpresponse(json_data)
        # after forms.py file fail the below lines will executes
        if form.errors:
            json_data = json.dumps(form.errors)
            return self.render_to_httpresponse(json_data,status=400)



# for varification of put method
@method_decorator(csrf_exempt,name='dispatch')
class EmployeeDetailDelete(HttpResponseMixin,SerializeMixin,View):
    def get_object_by_id(self,id):
        try:
            emp = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            return None
        return emp

    def delete(self,request,id,*args,**kwargs):
        emp = self.get_object_by_id(id)
        if emp is None:
            json_data = json.dumps({'msg':'Record Not Found,So Deletion oeraption is not Possible'})
            return self.render_to_httpresponse(json_data,status=404)
        # t = emp.delete()
        # ''' instead of getting empty object "t". we can get status code with given more information '''
        status,deleted_item= emp.delete()
        if status == 1:
            json_data = json.dumps({'msg':'Record deleted Successfully'})
            return self.render_to_httpresponse(json_data,status=400)
        # below lines will executes the if the status==0, something problem with database side
        json_data = json.dumps({'msg':'Unable to Delete the record, ..Try after sometime'})
        return self.render_to_httpresponse(json_data,status=400)
