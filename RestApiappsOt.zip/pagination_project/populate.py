import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','pagination_project.settings')
import django
django.setup()

from testapp.models import Employee
from faker import *
from  random import *
faker = Faker()

def populate(n):
    for i in range(n):
        feno = randint(1000,2000)
        fename = faker.name()
        fesal = randint(15000,25000)
        feaddr = faker.city()
        emp_record = Employee.objects.get_or_create(eno=feno,ename=fename,esal=fesal,eaddr=feaddr)
populate(120)
