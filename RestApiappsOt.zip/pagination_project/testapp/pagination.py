from rest_framework.pagination import PageNumberPagination,LimitOffsetPagination,CursorPagination

class MyPagination(PageNumberPagination):
    page_size = 5 # number records per page_size here
    page_query_param= 'mypage' # overriding the default query parameter name as 'mypage' instead of default "page"
    page_size_query_param= 'num' # allowing user to keep their desired number of pages
    max_page_size = 15 # restrict the accessing the more than max page_size
    last_page_strings=('endpage',) # overriding the default "last" page as desired string as "endpage"

class MyPagination2(LimitOffsetPagination):
    default_limit = 15
    limit_query_param = 'mylimit'
    offset_query_param = 'myoffset'
    max_limit = 9

class MyPagination3(CursorPagination):
    # pass # if pass argument as pass, considered default creatation order only, if created field is not available, here "created " field not in the field list
    ordering ='-esal' # "-" is desceding order 
    page_size = 5
