from django.shortcuts import render
from testapp.serializers import EmployeeModelSerializer
from testapp.models import Employee
from rest_framework import generics
# implementing pagination in locally
from testapp.pagination import MyPagination,MyPagination2,MyPagination3
# Create your views here.

# overriding the default pagination class


# class EmployeeListView(generics.ListAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeModelSerializer
#     # pagination_class = MyPagination # custom pagination class here
#     # pagination_class = MyPagination2 # LimitOffsetPagination demonstration
#     pagination_class = MyPagination3 #

'''demonstration of the filter(plain or vanilla) searching, filter ordering'''
class EmployeeListView(generics.ListAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    def get_queryset(self): # overriding the method
        qs = Employee.objects.all() # getting all records
        name = self.request.GET.get('ename') # capaturing user which passed over browser
        if name is not None: # if request contains the username then True and execute below code
            qs = qs.filter(ename__icontains=name)
        return qs

'''demonstration of the DRF based filtering'''
class EmployeeFiltering(generics.ListAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    # search_fields = ('ename','^eno')
    # search_fields = ('^eno',) # start with given eno
    search_fields = ('ename','eno')
    ordering_fields = ('eno','esal') # ordering specified fields only here. default values is (__all__)
