"""withrestc3 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path
from testapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('apio/',views.EmployeeAPIView.as_view()),
    path('apil/',views.EmployeeListAPIView.as_view()),
    path('apic/',views.EmployeeCreateAPIView.as_view()),
    # path('apir/<pk>',views.EmployeeRetrieveAPIView.as_view()),
    # path('apir/<id>',views.EmployeeRetrieveAPIView.as_view()),
    re_path(r'^apir/(?P<id>\d+)/$',views.EmployeeRetrieveAPIView.as_view()),
    path('apiu/<id>',views.EmployeeUpdateAPIView.as_view()),
    path('apid/<id>',views.EmployeeDestroyAPIView.as_view()),
    path('apilc/',views.EmployeeListCreateAPIView.as_view()),
    path('apiru/<id>',views.EmployeeRetrieveUpdateAPIView.as_view()),
    path('apird/<id>',views.EmployeeRetrieveDeleteAPIView.as_view()),
    path('apirud/<id>',views.EmployeeRetrieveUpdateDestroyAPIView.as_view()),
    # as per standered rule of API creatation, allowed only two end points those all belowed only
    re_path(r'^api/$',views.EmployeeListCreate_APIView.as_view()),
    re_path(r'api/(?P<id>\d+)/$',views.EmployeeRetrieveUpdateDestroy_APIView.as_view()),
    path('apilcmm/',views.EmployeeListCreateModelMixin.as_view()),
    path('apirudmm/<pk>',views.EmployeeRetrieveUpdateDestroyModelMixin.as_view())
]
