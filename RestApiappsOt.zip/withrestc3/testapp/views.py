from django.shortcuts import render
from testapp.serializers import EmployeeModelSerializer

from rest_framework.views import APIView
# class based views
from rest_framework.generics import ListAPIView,CreateAPIView
from rest_framework.response import Response
from testapp.models import Employee
# Create your views here.

class EmployeeAPIView(APIView): # APIView which is similar to function based views(FBV) is djangoproject
    def get(self,request,pk=None):
        qs = Employee.objects.all() # getting all objects
        serializers = EmployeeModelSerializer(qs,many=True) # serialization . converions of json data to python dict
        return Response(serializers.data) # python dict to json object with Response() class

# We can reduce the above lines with rest_framework built in class ListAPIView()
# demonstrating the queryset() similar to class based views (CBV)
class EmployeeListAPIView(ListAPIView): #
    # queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer # take care of display all records with ListAPIView() parent class

    # demonstrating the get filter name, find the ename which contains the krishna work
    def get_queryset(self): # it's built in method here
        qs = Employee.objects.all() # fetch all Employee details to qs object
        # if not passing the ename the all records will getting..
        # name = self.request.GET.get('ename') # out of all details get name only, below line taking the "xxx" in the browser query http://127.0.0.1:8000/api/?ename=krishna then filter only krishna Employee name only

        name = self.request.GET.get('xxx') # out of all details get name only,"xxx" in the browser query http://127.0.0.1:8000/api/?xxx=krishna then filter only krishna Employee name only

        if name is not None: # mean here is if name available,execute the below code
            qs = qs.filter(ename__icontains=name) # fillter out the name which contains "passed by user"
        return qs

# demonstrating the creating records with CreateAPIView view that from the Viewset() of serializers
# below class will create the record by taking details from the restapi browserable api from browser with url http://127.0.0.1:8000/apic/
class EmployeeCreateAPIView(CreateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer

'''
demonstrating the retrieve api views
'''
from rest_framework.generics import RetrieveAPIView
class EmployeeRetrieveAPIView(RetrieveAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    lookup_field = 'id'

''' demonstrating the update operation '''
from rest_framework.generics import UpdateAPIView
class EmployeeUpdateAPIView(UpdateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    lookup_field = 'id'

''' demonstrating the update operation '''
from rest_framework.generics import DestroyAPIView
class EmployeeDestroyAPIView(DestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    lookup_field = 'id'



''' demonstrating the both ListCreate peration together with help of hybird class '''
from rest_framework.generics import ListCreateAPIView
class EmployeeListCreateAPIView(ListCreateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    # lookup_field = 'id' , id field not require

''' demonstrating the both RetrieveUpdate operations together with help of hybird class '''
from rest_framework.generics import RetrieveUpdateAPIView
class EmployeeRetrieveUpdateAPIView(RetrieveUpdateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    lookup_field = 'id'  # id field not require

''' demonstrating the both RetrieveUpdate operations together with help of hybird class '''
from rest_framework.generics import RetrieveDestroyAPIView
class EmployeeRetrieveDeleteAPIView(RetrieveDestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    lookup_field = 'id'  # id field not require

''' demonstrating the both RetrieveUpdateDestroy operations together with help of hybird class '''
from rest_framework.generics import RetrieveUpdateDestroyAPIView
class EmployeeRetrieveUpdateDestroyAPIView(RetrieveUpdateDestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    lookup_field = 'id'  # id field not require

'''
As per the industry standered only allowed end points is two only.
So Developing api the all CuRD operations limit to Two end points only
'''
''' To perform both ListCreate one view'''
from rest_framework.generics import ListCreateAPIView
class EmployeeListCreate_APIView(ListCreateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    # lookup_field = 'id' , id field not require

''' To perform  RetrieveUpddateDestroy , meets the all requirements with help of the pk allowed class'''
''' demonstrating the both RetrieveUpdateDestroy operations together with help of hybird class '''
from rest_framework.generics import RetrieveUpdateDestroyAPIView
class EmployeeRetrieveUpdateDestroy_APIView(RetrieveUpdateDestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    lookup_field = 'id'  # id field not require


''' demonstrating the modelMixins'''
import rest_framework.generics
from rest_framework import mixins
class EmployeeListCreateModelMixin(mixins.CreateModelMixin,ListAPIView):
    ''' To achieve the functinality of listing(ListAPIView) as well as create object with of (mixin.CreateModelMixin) '''
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer
    def post(request,*args,**kwargs):
        return self.create(request,*args,**kwargs) # create() available with (supplied by the CreateModelMixin)


''' demonstrating the to actieve the retrieve,update,Destroy'''
# import rest_framework.generics
from rest_framework import mixins

class EmployeeRetrieveUpdateDestroyModelMixin(mixins.DestroyModelMixin,mixins.UpdateModelMixin,RetrieveAPIView):
    # ''' To achieve the functinality of Retrieve(veiwing), update(),Destroy()  all together with help of (mixin.CreateModelMixin)'''
    queryset = Employee.objects.all()
    serializer_class = EmployeeModelSerializer # until this we can perform only RetrieveAPIView--> only Retrieve operaion only
    def put(self,request,*args,**kwargs): # achieve the functinality of all fields update
        return self.update(request,*args,**kwargs) # create() available with (supplied by the RetrieveModelMixin)

    def patch(self,request,*args,**kwargs): # achieve the functinality of partial_update
        return self.partial_update(request,*args,**kwargs) # create() available with (supplied by the UpdateModelMixin)

    def delete(self,request,*args,**kwargs): # achieve the functinality of delete data with help of DestroyModelMixin
        return self.destroy(request,*args,**kwargs) # create() available with (supplied by the RetrieveModelMixin)

# class EmployeeRUDMM(mixins.UpdateModelMixin,RetrieveAPIView):
#     queryset = Employee.objects.all()
#     serializer_class = EmployeeModelSerializer
#
#     def put(request,*args,**kwargs):
#         return self.update(request,*args,**kwargs)
#
#     def patch(request,*args,**kwargs):
#         return self.partial_update(request,*args,**kwargs)
