from rest_framework.serializers import ModelSerializer
from testapp.models import Employee

class EmployeeModelSerializer(ModelSerializer):
    ''' demonstration of implementaions of model serializers'''
    # esal = serializers.FloatField(validators=[multiple_of_1000]) # validation on salary field
    class  Meta:
        model = Employee
        # fields = ['eno','ename','eaddr'] # allowed fields
        # exclude = ['esal'] # restricted fields not allowed to participate
        fields = '__all__' # all fields allowed.
