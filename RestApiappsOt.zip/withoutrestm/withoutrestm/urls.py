"""withoutrestm URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from testapp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('modelapi/',views.EmployeeDetailCBV.as_view()),
    path('modelapi/<id>',views.EmployeeDetailCBVUser.as_view()),
    path('modelserial/<id>',views.EmployeeDetailCBVserializer.as_view()),
    path('modelallrecords/',views.EmployeeDetailListCBV.as_view()),
    path('modelserialall/',views.EmployeeDetailListCBVwithFields.as_view()),
    path('modelserialmixin/',views.EmployeeDetailCBVserializerMixin.as_view()),
    path('modeltryexcept/<id>',views.EmployeeTryExcept.as_view()),
    path('tryexceptclient',views.EmployeeTryExceptOverClient.as_view()),
    path('mixinhttp/<id>',views.EmployeeDetailCBVMixinHttp.as_view()),
    path('posttomodel/',views.EmployeeDetailCBVPost.as_view()),
    path('formvalidation/<id>',views.EmployeeDetailCBVPostFormValidation.as_view()),
    path('detailsput/<id>',views.EmployeeDetailPut.as_view()),
    path('itemdelete/<id>',views.EmployeeDetailDelete.as_view())

]
