from rest_framework import serializers
from testapp.models import Employee

# due to we using the normal Serializer. need to write below code, view
def multiple_of_1000(value):
    print('validation by using validators attribute')
    if value %1000 != 0:
        raise serializers.ValidationError('Employee salary should be multiplels of 1000\'s only')
    # return value

class EmployeeModelSerializer(serializers.ModelSerializer):
    ''' demonstration of implementaions ofm odel serializers'''
    esal = serializers.FloatField(validators=[multiple_of_1000]) # validation on salary field
    class  Meta:
        model = Employee
        # fields = ['eno','ename','eaddr'] # allowed fields
        # exclude = ['esal'] # restricted fields not allowed to participate 
        fields = '__all__' # all fields allowed.

# class EmployeeSerializer(serializers.Serializer):
#     eno = serializers.IntegerField()
#     ename = serializers.CharField(max_length=64)
#     esal = serializers.IntegerField(validators=[multiple_of_1000,]) # demonstration of built in validators(last method of validation) 0r by using validators. First priority
#     eaddr = serializers.CharField()
#
#     def validate_esal(self,value): # demonstration of field leval validation, priority leve 2nd
#         print('field level validations')
#         if value < 5000: # while executing is_valid method by calling validate_esal
#             raise serializers.ValidationError('Employee salary shoud be mininum 5000') # message will be send to serializer.erros method
#         return value
#
#     def validate(self,data): # demonstration of object level validation, data attribute contains the multiple files. property level will be 3rd s
#         print('object level validataions ') #
#         ename = data.get('ename')
#         esal = data.get('esal')
#
#         if ename.lower() == 'Varun':
#             if esal < 50000:
#                 raise serializers.ValidationError('Varun salary shoud be mininum 50000') # message sending to serializer.errors
#         return data # return data after validation
#
#
#     def create(self,validated_data): # its instance method
#         return Employee.objects.create(**validated_data) # contain key-value pairs
#
#     def update(self,instance,validated_data):  #here validated_data should be updated to existing instance
#         instance.eno = validated_data.get('eno',instance.eno) # update shoud validated_data.eno new data else existing eno
#         instance.ename = validated_data.get('ename',instance.ename)
#         instance.esal = validated_data.get('esal',instance.esal)
#         instance.eaddr = validated_data.get('eaddr',instance.eaddr)
#         instance.save()
#         return instance
