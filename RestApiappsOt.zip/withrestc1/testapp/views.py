from django.shortcuts import render
from django.views.generic import View
from testapp.models import Employee
# from testapp.serializers import EmployeeSerializer
from testapp.serializers import EmployeeModelSerializer
from django.http.response import HttpResponse
import io
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

# diabling the csrf token
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
@method_decorator(csrf_exempt,name='dispatch')
class EmployeeCURDCBV(View):

    # def get(self,request,*args,**kwargs):
        # json_data = request.body # json data
        # stream = io.BytesIO(json_data)
        # pdata = JSONParser().parse(stream) # json to python navtive data type
        # id = pdata.get('id',None)
        # if id is not None: # if the id is exists
        #     emp = Employee.objects.get(id=id)
        #     eserializer = EmployeeSerializer(emp) # after Serializer should call as Serializer.data
        #     json_data = JSONRenderer().render(eserializer.data) # python dict to json data
        #     return HttpResponse(json_data,content_type='application/json')
        #
        # qs = Employee.objects.all() # if id not exists
        # eserializer = EmployeeSerializer(qs,many=True)
        # json_data = JSONRenderer().render(eserializer.data) # python dict to json data
        # return HttpResponse(json_data,content_type='application/json')

    def get(self,request,*args,**kwargs):
        json_data = request.body # json data
        stream = io.BytesIO(json_data)
        pdata = JSONParser().parse(stream) # json to python navtive data type
        id = pdata.get('id',None)
        if id is not None: # if the id is exists
            emp = Employee.objects.get(id=id)
            eserializer = EmployeeModelSerializer(emp) # after Serializer should call as Serializer.data
            json_data = JSONRenderer().render(eserializer.data) # python dict to json data
            return HttpResponse(json_data,content_type='application/json')

        qs = Employee.objects.all() # if id not exists
        eserializer = EmployeeModelSerializer(qs,many=True)
        json_data = JSONRenderer().render(eserializer.data) # python dict to json data
        return HttpResponse(json_data,content_type='application/json')

    # def post(self,request,*args,**kwargs):
    #     json_data = request.body # json data
    #     stream = io.BytesIO(json_data)
    #     pdata = JSONParser().parse(stream) # json to python navtive data type
    #     serializer = EmployeeSerializer(data=pdata)
    #     if serializer.is_valid():
    #         serializer.save()
    #         message = {'msg':'Resources created successfully'} # sending response to pather application
    #         return HttpResponse(json_data,content_type='application/json') # retrun the response
    #         json_data = JSONRenderer().render(message) # converting response python dict to json data
    #     json_data =  JSONRenderer().render(serializer.errors) # if serializer is not valid. send the error to client
    #     return HttpResponse(json_data,content_type='application/json') # response retunr


    def post(self,request,*args,**kwargs):
        json_data = request.body # json data
        stream = io.BytesIO(json_data)
        pdata = JSONParser().parse(stream) # json to python navtive data type
        serializer = EmployeeModelSerializer(data=pdata)
        if serializer.is_valid():
            serializer.save()
            message = {'msg':'Resources created successfully'} # sending response to pather application
            return HttpResponse(json_data,content_type='application/json') # retrun the response
            json_data = JSONRenderer().render(message) # converting response python dict to json data
        json_data =  JSONRenderer().render(serializer.errors) # if serializer is not valid. send the error to client
        return HttpResponse(json_data,content_type='application/json') # response retunr


    # def put(self,request,*args,**kwargs):
    #     json_data = request.body # json data
    #     stream = io.BytesIO(json_data)
    #     pdata = JSONParser().parse(stream) # json to python navtive data type
    #     id = pdata.get('id')
    #     emp = Employee.objects.get(id=id)
    #     serializer = EmployeeSerializer(emp,data=pdata,partial=True) # emp need to update to, with partial arguments--> then only we perform partial updated
    #     if serializer.is_valid(): # field level validation happend here
    #         serializer.save() # automatically serializer.py update method will call automatically
    #         message = {'msg':'Resources updated successfully'} # sending response to pather application
    #         return HttpResponse(json_data,content_type='application/json') # retrun the response
    #         json_data = JSONRenderer().render(message) # converting response python dict to json data
    #     json_data =  JSONRenderer().render(serializer.errors) # if serializer is not valid. send the error to client
    #     return HttpResponse(json_data,content_type='application/json') # response retunr

    def put(self,request,*args,**kwargs):
        json_data = request.body # json data
        stream = io.BytesIO(json_data)
        pdata = JSONParser().parse(stream) # json to python navtive data type
        id = pdata.get('id')
        emp = Employee.objects.get(id=id)
        serializer = EmployeeModelSerializer(emp,data=pdata,partial=True) # emp need to update to, with partial arguments--> then only we perform partial updated
        if serializer.is_valid(): # field level validation happend here
            serializer.save() # automatically serializer.py update method will call automatically
            message = {'msg':'Resources updated successfully'} # sending response to pather application
            return HttpResponse(json_data,content_type='application/json') # retrun the response
            json_data = JSONRenderer().render(message) # converting response python dict to json data
        json_data =  JSONRenderer().render(serializer.errors) # if serializer is not valid. send the error to client
        return HttpResponse(json_data,content_type='application/json') # response retunr


    def delete(self,request,*args,**kwargs):
        json_data = request.body # json data
        stream = io.BytesIO(json_data)
        pdata = JSONParser().parse(stream) # json to python navtive data type
        id = pdata.get('id')
        emp = Employee.objects.get(id=id)
        emp.delete()
        message = {'msg':'Resources deleted successfully'} # sending response to pather application
        json_data = JSONRenderer().render(message)
        return HttpResponse(json_data,content_type='application/json') # retrun the response
